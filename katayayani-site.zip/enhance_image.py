import numpy as np
from PIL import Image, ImageEnhance, ImageFilter

def enhance():
    # Load original and transparent images
    print("Opening images...")
    orig = Image.open('public/hero-tractor.png').convert('RGB')
    trans = Image.open('public/hero-tractor-transparent.png')
    
    # Get alpha channel from transparent image
    alpha = trans.split()[3]
    
    # Convert to numpy arrays for math
    orig_arr = np.array(orig, dtype=float)
    alpha_arr = np.array(alpha, dtype=float) / 255.0
    
    # Background color estimate from corners
    bg_color = np.array([238.0, 229.0, 217.0])
    
    # De-contaminate foreground
    # F = (Orig - (1 - A) * B) / A
    print("De-contaminating edge colors...")
    fg_arr = np.zeros_like(orig_arr)
    for i in range(3):
        # Avoid division by zero
        denom = np.maximum(alpha_arr, 0.001)
        fg_channel = (orig_arr[:, :, i] - (1.0 - alpha_arr) * bg_color[i]) / denom
        fg_arr[:, :, i] = np.clip(fg_channel, 0, 255)
        
    fg_img = Image.fromarray(fg_arr.astype(np.uint8), 'RGB')
    
    # Enhance contrast, sharpness, and color to restore premium 3D look
    print("Applying image enhancements (contrast, color, sharpness)...")
    # Increase contrast to make the lighting and details pop
    enhancer_contrast = ImageEnhance.Contrast(fg_img)
    fg_enhanced = enhancer_contrast.enhance(1.12)
    
    # Increase color saturation slightly to make Swaraj colors pop
    enhancer_color = ImageEnhance.Color(fg_enhanced)
    fg_enhanced = enhancer_color.enhance(1.08)
    
    # Increase sharpness to make the tractor crisp
    enhancer_sharpness = ImageEnhance.Sharpness(fg_enhanced)
    fg_enhanced = enhancer_sharpness.enhance(1.15)
    
    # Smooth the alpha channel slightly to eliminate jagged edges and ensure smooth blending
    print("Softening alpha edges...")
    alpha_smooth = alpha.filter(ImageFilter.GaussianBlur(0.6))
    
    # Recombine enhanced foreground with smooth alpha
    final_img = Image.merge('RGBA', (*fg_enhanced.split(), alpha_smooth))
    
    # Save the updated image
    print("Saving final image...")
    final_img.save('public/hero-tractor-transparent.png')
    print("Success! Enhanced image saved to public/hero-tractor-transparent.png")

if __name__ == '__main__':
    enhance()
