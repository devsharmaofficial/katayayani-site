from rembg import remove
from PIL import Image
import sys

def main():
    try:
        input_path = 'public/hero-tractor.png'
        output_path = 'public/hero-tractor-transparent.png'
        
        print("Opening image...")
        inp = Image.open(input_path)
        print("Removing background...")
        output = remove(inp)
        print("Saving image...")
        output.save(output_path)
        print("Success!")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
